# Contact Us

For technical support or any type of inquiries, you are very welcome to:

- Reach out to community members on the [**Prowler Slack channel**](https://join.slack.com/t/prowler-workspace/shared_invite/zt-1hix76xsl-2uq222JIXrC7Q8It~9ZNog)

- Open an Issue or a Pull Request in our [**GitHub repository**](https://github.com/prowler-cloud/prowler).

We will appreciate all types of feedback and contribution, Prowler would not be the same without our vibrant community! 😃
