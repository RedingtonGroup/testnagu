#!/usr/bin/env python3

import sys

from prowler.__main__ import prowler

if __name__ == "__main__":
    sys.exit(prowler())
